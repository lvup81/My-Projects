package com.punith.SpringWeb1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWeb1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringWeb1Application.class, args);
	}

}
