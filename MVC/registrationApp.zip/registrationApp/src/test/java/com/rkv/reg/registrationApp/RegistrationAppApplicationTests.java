package com.rkv.reg.registrationApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
